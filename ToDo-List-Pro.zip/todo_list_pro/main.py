# -*- coding: utf-8 -*-
"""
main.py
===========================================================================
پروژه  : نرم‌افزار مدیریت پیشرفته لیست کارهای روزانه (To-Do List Pro)
بخش    : رابط کاربری گرافیکی چندفرمی با Tkinter (GUI Layer)
---------------------------------------------------------------------------
پنجره‌ها / فرم‌ها:
    1) MainWindow      : فرم اصلی (نمایش تاریخ و ساعت سیستم، جدول کارها،
                         دکمه‌های افزودن/حذف/ویرایش/فیلتر/ذخیره/بارگذاری)
    2) TaskFormDialog  : فرم افزودن یا ویرایش کار
    3) SearchWindow    : فرم جستجو و فیلتر بر اساس عنوان/تاریخ/اولویت/وضعیت
    4) ReportWindow    : فرم گزارش‌گیری روزانه یا بازه‌ای + خروجی/چاپ/کپی

اجرا:
    pip install plyer        (اختیاری؛ برای اعلان دسکتاپ)
    python main.py
===========================================================================
"""

from __future__ import annotations

# --- کتابخانه‌های استاندارد -------------------------------------------------
import os
import sys
import shutil
import tempfile
import subprocess
from datetime import datetime, date, timedelta
from pathlib import Path

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# --- ماژول‌های پروژه --------------------------------------------------------
from models import Task, TodoList, PRIORITIES, DATE_FORMAT
import utils
from utils import (
    build_range_report, build_full_report,
    report_for_date, save_report, default_report_filename,
    is_valid_date, today_str, relative_due_text,
    last_7_days_range, next_7_days_range,
    Notifier, pick_fa_font, copy_to_clipboard, COLOR_DONE, COLOR_OVERDUE,
)

# --- مسیر پایه و فایل داده --------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data.txt")

# --- نام نماها (View) در فرم اصلی -------------------------------------------
VIEW_ALL = "همه کارها"
VIEW_TODAY = "کارهای امروز"
VIEW_OVERDUE = "کارهای عقب‌افتاده"
VIEW_DONE = "انجام‌شده‌ها"
VIEW_PENDING = "انجام‌نشده‌ها"
VIEWS = (VIEW_ALL, VIEW_TODAY, VIEW_OVERDUE, VIEW_DONE, VIEW_PENDING)

ALL_PRIORITIES = "همه اولویت‌ها"
ALL_STATUSES = "همه وضعیت‌ها"


# === ویجت متن قابل اسکرول (برای نمایش گزارش‌ها) ==============================
class ScrollableTextFrame(ttk.Frame):
    """قاب شامل یک ویجت Text همراه اسکرول‌بار عمودی (برای پیش‌نمایش گزارش)."""

    def __init__(self, master, font_tuple, height=14, **kwargs):
        super().__init__(master, **kwargs)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.text = tk.Text(
            self, wrap="word", height=height, font=font_tuple,
            bg="#FFFFFF", fg="#212121", relief="solid", borderwidth=1,
            padx=12, pady=10, undo=True,
        )
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scrollbar.set)

        self.text.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

    # --- توابع کمکی ---
    def set_text(self, content: str) -> None:
        """جایگزینی کل متن."""
        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)

    def get_text(self) -> str:
        """دریافت کل متن."""
        return self.text.get("1.0", "end-1c")

    def clear(self) -> None:
        """پاک‌کردن متن."""
        self.text.delete("1.0", "end")


# === کلاس پایه‌ی فرم‌های ثانویه =============================================
class BaseForm(tk.Toplevel):
    """پایه‌ی مشترک همه‌ی پنجره‌های فرعی (فونت، ارجاع به برنامه، تنظیمات عمومی)."""

    def __init__(self, master, app: "MainWindow", title: str,
                 geometry: str | None = None, resizable: bool = True):
        super().__init__(master)
        self.app = app
        self.font_family = app.font_family
        self.font_size = app.font_size
        self.font = (self.font_family, self.font_size)
        self.font_bold = (self.font_family, self.font_size, "bold")

        self.title(title)
        if geometry:
            self.geometry(geometry)
        self.transient(master)          # وابسته به پنجره‌ی اصلی
        self.resizable(resizable, resizable)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.configure(bg="#F5F7FA")

    def center_on_parent(self) -> None:
        """قرار دادن پنجره در وسط پنجره‌ی والد."""
        self.update_idletasks()
        try:
            px, py = self.master.winfo_rootx(), self.master.winfo_rooty()
            pw, ph = self.master.winfo_width(), self.master.winfo_height()
        except tk.TclError:
            return
        w, h = self.winfo_width(), self.winfo_height()
        x = max(px + (pw - w) // 2, 0)
        y = max(py + (ph - h) // 2, 0)
        self.geometry(f"+{x}+{y}")


# === فرم ۱: پنجره‌ی اصلی =====================================================
class MainWindow(tk.Tk):
    """فرم اصلی برنامه: جدول کارها + نوار ابزار + فیلترها + آمار + ساعت."""

    def __init__(self):
        super().__init__()

        # --- داده‌ها و تنظیمات -------------------------------------------------
        self.todo_list = TodoList()
        self.data_file = DATA_FILE
        self.font_family, self.font_size = "TkDefaultFont", 10
        self._dirty = False                       # آیا تغییر ذخیره‌نشده وجود دارد؟
        self._child_windows: dict[str, tk.Toplevel | None] = {"search": None, "report": None}

        # --- شناسه‌ی پنجره و عنوان --------------------------------------------
        self.title("To-Do List Pro | نرم‌افزار مدیریت پیشرفته کارهای روزانه")
        self.geometry("1120x700")
        self.minsize(920, 560)

        # --- انتخاب فونت فارسی موجود در سیستم ---------------------------------
        self.font_family, self.font_size = pick_fa_font(self, 10)
        self.font = (self.font_family, self.font_size)
        self.font_bold = (self.font_family, self.font_size, "bold")
        self.font_title = (self.font_family, 17, "bold")
        self.font_clock = (self.font_family, 11, "bold")

        # --- نوتیفایر ------------------------------------------------------------
        self.notifier = Notifier(fallback_master=self)

        # --- استایل‌دهی ttk -----------------------------------------------------
        self._setup_style()

        # --- ساخت ویجت‌ها -------------------------------------------------------
        self._build_header()
        self._build_toolbar()
        self._build_filters()
        self._build_table()
        self._build_footer()

        # --- میان‌برهای صفحه‌کلید ------------------------------------------------
        self.bind("<Control-n>", lambda e: self.add_task_dialog())
        self.bind("<F2>", lambda e: self.edit_selected_task())
        self.bind("<Delete>", lambda e: self.delete_selected_task())
        self.bind("<Control-s>", lambda e: self.save_data())
        self.bind("<Control-r>", lambda e: self.open_report_window())

        # --- آماده‌سازی داده‌ها --------------------------------------------------
        self._prepare_data()

        # --- ساعت زنده + اعلان خودکار ------------------------------------------
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._tick_clock()
        self.after(1400, self._startup_notification)

    # ------------------------------------------------------------------ #
    #                        ساخت اجزای رابط کاربری                      #
    # ------------------------------------------------------------------ #
    def _setup_style(self) -> None:
        """تنظیم استایل و تم ttk برای ظاهر مرتب و خوانا."""
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", font=self.font)
        style.configure("TButton", padding=(10, 6), font=self.font)
        style.configure("Toolbar.TButton", padding=(12, 7), font=self.font)
        style.configure("Accent.TButton", padding=(14, 8), font=self.font_bold,
                        background="#0D6EFD", foreground="white")
        style.map("Accent.TButton",
                  background=[("active", "#0B5ED7"), ("pressed", "#0A53BE")])
        style.configure("Danger.TButton", padding=(10, 6), font=self.font,
                        background="#DC3545", foreground="white")
        style.map("Danger.TButton", background=[("active", "#BB2D3B")])
        style.configure("TLabel", font=self.font)
        style.configure("Header.TLabel", font=self.font_bold)
        style.configure("TLabelframe", font=self.font_bold)
        style.configure("TLabelframe.Label", font=self.font_bold)
        style.configure("TCombobox", font=self.font)
        style.configure("TEntry", font=self.font)
        style.configure("TCheckbutton", font=self.font)

        style.configure("Treeview", font=self.font, rowheight=30,
                        background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=self.font_bold)
        style.map("Treeview",
                  background=[("selected", "#0D6EFD")],
                  foreground=[("selected", "white")])

    def _build_header(self) -> None:
        """سربرگ رنگی: عنوان برنامه + تاریخ/ساعت زنده‌ی سیستم."""
        header = tk.Frame(self, bg="#1E3A5F", padx=20, pady=12)
        header.grid(row=0, column=0, sticky="ew")

        left = tk.Frame(header, bg="#1E3A5F")
        left.pack(side="left")
        tk.Label(left, text="To-Do List Pro", bg="#1E3A5F", fg="#FFFFFF",
                 font=(self.font_family, 19, "bold")).pack(anchor="w")
        tk.Label(left, text="نرم‌افزار مدیریت پیشرفته لیست کارهای روزانه",
                 bg="#1E3A5F", fg="#BBDEFB", font=self.font).pack(anchor="w")

        right = tk.Frame(header, bg="#1E3A5F")
        right.pack(side="right")
        self.clock_date_label = tk.Label(right, text="", bg="#1E3A5F", fg="#FFFFFF",
                                         font=self.font_clock)
        self.clock_date_label.pack(anchor="e")
        self.clock_time_label = tk.Label(right, text="", bg="#1E3A5F", fg="#90CAF9",
                                         font=(self.font_family, 12, "bold"))
        self.clock_time_label.pack(anchor="e")

    def _build_toolbar(self) -> None:
        """نوار ابزار اصلی با دکمه‌های عملیات."""
        toolbar = ttk.Frame(self, padding=(14, 10, 14, 4))
        toolbar.grid(row=1, column=0, sticky="ew")

        buttons = [
            ("افزودن کار", self.add_task_dialog, "Accent.TButton"),
            ("ویرایش", self.edit_selected_task, "Toolbar.TButton"),
            ("حذف", self.delete_selected_task, "Danger.TButton"),
            ("تغییر وضعیت", self.toggle_selected_task, "Toolbar.TButton"),
        ]
        for text, command, style_name in buttons:
            ttk.Button(toolbar, text=text, command=command,
                       style=style_name).pack(side="left", padx=3)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10)

        more_buttons = [
            ("جستجو و فیلتر", self.open_search_window),
            ("گزارش‌گیری", self.open_report_window),
            ("اعلان", self.send_notification_now),
        ]
        for text, command in more_buttons:
            ttk.Button(toolbar, text=text, command=command,
                       style="Toolbar.TButton").pack(side="left", padx=3)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10)

        ttk.Button(toolbar, text="ذخیره", command=self.save_data,
                   style="Toolbar.TButton").pack(side="left", padx=3)
        ttk.Button(toolbar, text="بارگذاری", command=self.load_data,
                   style="Toolbar.TButton").pack(side="left", padx=3)

        ttk.Label(toolbar, text="Ctrl+N افزودن | F2 ویرایش | Ctrl+S ذخیره",
                  foreground="#607D8B").pack(side="right")

    def _build_filters(self) -> None:
        """نوار فیلتر: نما، اولویت و جستجوی سریع (زنده)."""
        bar = ttk.Frame(self, padding=(14, 4, 14, 8))
        bar.grid(row=2, column=0, sticky="ew")

        ttk.Label(bar, text="نما:").pack(side="left")
        self.view_var = tk.StringVar(value=VIEW_ALL)
        view_box = ttk.Combobox(bar, textvariable=self.view_var, values=VIEWS,
                                state="readonly", width=18)
        view_box.pack(side="left", padx=(4, 14))
        view_box.bind("<<ComboboxSelected>>", lambda e: self.refresh_table())

        ttk.Label(bar, text="اولویت:").pack(side="left")
        self.priority_var = tk.StringVar(value=ALL_PRIORITIES)
        prio_box = ttk.Combobox(bar, textvariable=self.priority_var,
                                values=(ALL_PRIORITIES,) + PRIORITIES,
                                state="readonly", width=13)
        prio_box.pack(side="left", padx=(4, 14))
        prio_box.bind("<<ComboboxSelected>>", lambda e: self.refresh_table())

        ttk.Label(bar, text="جستجوی سریع:").pack(side="left")
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(bar, textvariable=self.search_var, width=26)
        search_entry.pack(side="left", padx=(4, 10))
        self.search_var.trace_add("write", lambda *_: self.refresh_table())

        ttk.Button(bar, text="پاک‌کردن فیلتر", command=self.clear_filters).pack(side="left", padx=3)

        self.count_var = tk.StringVar(value="")
        ttk.Label(bar, textvariable=self.count_var, foreground="#37474F").pack(side="right")

    def _build_table(self) -> None:
        """جدول (Treeview) نمایش کارها همراه اسکرول‌بار."""
        frame = ttk.Frame(self, padding=(14, 0, 14, 8))
        frame.grid(row=3, column=0, sticky="nsew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        columns = ("title", "status", "priority", "due", "created")
        self.tree = ttk.Treeview(frame, columns=columns, show="headings",
                                 selectmode="browse")

        headings = {
            "title": "عنوان کار",
            "status": "وضعیت",
            "priority": "اولویت",
            "due": "تاریخ سررسید",
            "created": "تاریخ ایجاد",
        }
        widths = {"title": 380, "status": 100, "priority": 90, "due": 190, "created": 150}
        anchors = {"title": "w", "status": "center", "priority": "center",
                   "due": "center", "created": "center"}

        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor=anchors[col],
                             stretch=(col == "title"))

        # --- تگ‌های رنگی -------------------------------------------------------
        self.tree.tag_configure("p_بالا", background="#FDECEA", foreground="#B71C1C")
        self.tree.tag_configure("p_متوسط", background="#FFF8E1", foreground="#8D6E00")
        self.tree.tag_configure("p_پایین", background="#E8F5E9", foreground="#1B5E20")
        self.tree.tag_configure("overdue", background="#FFEBEE", foreground=COLOR_OVERDUE)
        self.tree.tag_configure("done", background="#F5F5F5", foreground=COLOR_DONE)

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        self.tree.bind("<Double-1>", lambda e: self.toggle_selected_task())
        self.tree.bind("<Return>", lambda e: self.toggle_selected_task())
        self.tree.bind("<F2>", lambda e: self.edit_selected_task())
        self.tree.bind("<Delete>", lambda e: self.delete_selected_task())

    def _build_footer(self) -> None:
        """پایین‌برگ: آمار زنده + پیام وضعیت + مسیر فایل داده."""
        footer = tk.Frame(self, bg="#ECEFF1", padx=16, pady=8)
        footer.grid(row=4, column=0, sticky="ew")

        self.stats_var = tk.StringVar(value="")
        tk.Label(footer, textvariable=self.stats_var, bg="#ECEFF1",
                 fg="#263238", font=self.font_bold).pack(side="left")

        self.status_var = tk.StringVar(value="آماده")
        tk.Label(footer, textvariable=self.status_var, bg="#ECEFF1",
                 fg="#546E7A", font=self.font).pack(side="left", padx=20)

        tk.Label(footer, text=f"فایل داده: {self.data_file}", bg="#ECEFF1",
                 fg="#90A4AE", font=(self.font_family, 8)).pack(side="right")

        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

    # ------------------------------------------------------------------ #
    #                        ساعت زنده و پیام وضعیت                       #
    # ------------------------------------------------------------------ #
    def _tick_clock(self) -> None:
        """به‌روزرسانی هر ثانیه‌ای تاریخ و ساعت سیستم در سربرگ."""
        try:
            persian_digits = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
            self.clock_date_label.configure(text=f"امروز: {utils.format_persian_date()}")
            self.clock_time_label.configure(
                text=datetime.now().strftime("%H:%M:%S").translate(persian_digits))
        except tk.TclError:
            return
        self.after(1000, self._tick_clock)

    def set_status(self, message: str, dirty: bool = False) -> None:
        """نمایش پیام در نوار وضعیت و ثبت وضعیت «ذخیره‌نشده»."""
        if dirty:
            self._dirty = True
        self.status_var.set(f"{message}  (تغییرات ذخیره‌نشده)" if self._dirty else message)

    # ------------------------------------------------------------------ #
    #                        داده‌ها: آماده‌سازی/ذخیره                     #
    # ------------------------------------------------------------------ #
    def _prepare_data(self) -> None:
        """بارگذاری فایل داده؛ در صورت نبود فایل، ساخت داده‌های نمونه."""
        if os.path.exists(self.data_file):
            count = self.todo_list.load_from_file(self.data_file)
            self.set_status(f"{count} کار از فایل بارگذاری شد.")
        else:
            self._create_sample_data()
            self.todo_list.save_to_file(self.data_file)
            self.set_status("فایل data.txt ساخته شد و چند کار نمونه ثبت گردید.")

        self._dirty = False
        self.refresh_table()

    def _create_sample_data(self) -> None:
        """ساخت چند تسک نمونه برای آشنایی اولیه با برنامه."""
        def d(offset: int) -> str:
            return (date.today() + timedelta(days=offset)).strftime(DATE_FORMAT)

        samples = [
            Task("مطالعه فصل سوم کتاب پایتون", "بالا", d(0)),
            Task("شرکت در جلسه تیم توسعه", "متوسط", d(0)),
            Task("ورزش صبحگاهی", "پایین", d(0)),
            Task("پرداخت قبض برق", "بالا", d(-1)),      # عقب‌افتاده
            Task("نوشتن گزارش هفتگی", "متوسط", d(2)),
            Task("خرید هدیه تولد", "پایین", d(5)),
        ]
        samples[-1].mark_done(True)                      # یک نمونه انجام‌شده
        for task in samples:
            self.todo_list.add_task(task)

    def save_data(self) -> bool:
        """ذخیره‌ی همه‌ی کارها در data.txt."""
        try:
            count = self.todo_list.save_to_file(self.data_file)
        except OSError as error:
            messagebox.showerror("خطا در ذخیره‌سازی",
                                 f"ذخیره‌ی فایل ممکن نشد:\n{error}", parent=self)
            return False

        self._dirty = False
        self.set_status(f"{count} کار با موفقیت در data.txt ذخیره شد.")
        return True

    def load_data(self) -> None:
        """بازیابی کارها از data.txt."""
        if not os.path.exists(self.data_file):
            messagebox.showwarning("فایل پیدا نشد",
                                   f"فایلی در مسیر زیر وجود ندارد:\n{self.data_file}",
                                   parent=self)
            return
        if self._dirty and not messagebox.askyesno(
                "بازیابی", "تغییرات ذخیره‌نشده از دست می‌رود. ادامه می‌دهید؟",
                parent=self):
            return
        try:
            count = self.todo_list.load_from_file(self.data_file)
        except OSError as error:
            messagebox.showerror("خطا در بازیابی",
                                 f"خواندن فایل ممکن نشد:\n{error}", parent=self)
            return
        self._dirty = False
        self.refresh_table()
        self.set_status(f"{count} کار از فایل بازیابی شد.")

    # ------------------------------------------------------------------ #
    #                        جدول: محاسبه و نمایش                        #
    # ------------------------------------------------------------------ #
    def _view_tasks(self) -> list[Task]:
        """انتخاب فهرست تسک‌ها بر اساس نمای فعلی."""
        view = self.view_var.get()
        if view == VIEW_TODAY:
            return self.todo_list.today_tasks()
        if view == VIEW_OVERDUE:
            return self.todo_list.overdue_tasks()
        if view == VIEW_DONE:
            return self.todo_list.list_by_status(True)
        if view == VIEW_PENDING:
            return self.todo_list.list_by_status(False)
        return self.todo_list.list_tasks()

    def refresh_table(self) -> None:
        """به‌روزرسانی جدول بر اساس نما + اولویت + جستجوی سریع، و آمار پایین."""
        try:
            tasks = self._view_tasks()
        except (tk.TclError, ValueError):
            tasks = self.todo_list.list_tasks()

        # --- فیلتر جستجوی سریع (عنوان) ----------------------------------------
        keyword = self.search_var.get().strip().lower() if hasattr(self, "search_var") else ""
        if keyword:
            tasks = [t for t in tasks if keyword in t.title.lower()]

        # --- فیلتر اولویت -------------------------------------------------------
        priority = self.priority_var.get() if hasattr(self, "priority_var") else ALL_PRIORITIES
        if priority in PRIORITIES:
            tasks = [t for t in tasks if t.priority == priority]

        # --- حفظ انتخاب فعلی ---------------------------------------------------
        previously_selected = set(self.tree.selection())

        # --- پرکردن مجدد جدول --------------------------------------------------
        for item in self.tree.get_children():
            self.tree.delete(item)

        for task in tasks:
            if task.is_done:
                tags = ("done",)
            elif task.is_overdue():
                tags = ("overdue",)
            else:
                tags = (f"p_{task.priority}",)

            self.tree.insert(
                "", "end", iid=task.task_id, tags=tags,
                values=(task.title, task.status_text, task.priority,
                        relative_due_text(task) or "—", task.created_date_str),
            )

        # --- بازگرداندن انتخاب -------------------------------------------------
        still_visible = [tid for tid in previously_selected if self.tree.exists(tid)]
        if still_visible:
            self.tree.selection_set(still_visible[0])
            self.tree.focus(still_visible[0])

        # --- آمار و شمارنده -----------------------------------------------------
        stats = self.todo_list.statistics()
        self.stats_var.set(
            f"کل: {stats['total']}   |   انجام‌شده: {stats['done']}   |   "
            f"باقی‌مانده: {stats['pending']}   |   عقب‌افتاده: {stats['overdue']}   |   "
            f"امروز: {stats['today']}"
        )
        self.count_var.set(f"نمایش: {len(tasks)} کار")

    def clear_filters(self) -> None:
        """بازگرداندن همه‌ی فیلترها به حالت اولیه."""
        self.view_var.set(VIEW_ALL)
        self.priority_var.set(ALL_PRIORITIES)
        self.search_var.set("")
        self.refresh_table()
        self.set_status("فیلترها پاک شدند.")

    # ------------------------------------------------------------------ #
    #                        عملیات روی کارها                            #
    # ------------------------------------------------------------------ #
    def _selected_task(self) -> Task | None:
        """دریافت تسک انتخاب‌شده در جدول (یا نمایش هشدار)."""
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("انتخاب کار",
                                "ابتدا یک کار را از جدول انتخاب کنید.", parent=self)
            return None
        task = self.todo_list.get_by_id(selection[0])
        if task is None:
            messagebox.showwarning("یافت نشد",
                                   "کار انتخاب‌شده در حافظه یافت نشد. جدول به‌روزرسانی می‌شود.",
                                   parent=self)
            self.refresh_table()
        return task

    def add_task_dialog(self) -> None:
        """بازکردن فرم افزودن کار جدید."""
        dialog = TaskFormDialog(self, self)
        self.wait_window(dialog)
        if not dialog.result:
            return

        try:
            task = Task(
                title=dialog.result["title"],
                priority=dialog.result["priority"],
                due_date=dialog.result["due_date"],
            )
            task.mark_done(dialog.result["is_done"])
            self.todo_list.add_task(task)
        except ValueError as error:
            messagebox.showerror("خطای اعتبارسنجی", str(error), parent=self)
            return

        self.refresh_table()
        self.set_status(f"کار «{task.title}» افزوده شد.", dirty=True)

    def edit_selected_task(self) -> None:
        """بازکردن فرم ویرایش برای کار انتخاب‌شده."""
        task = self._selected_task()
        if task is None:
            return

        dialog = TaskFormDialog(self, self, task=task)
        self.wait_window(dialog)
        if not dialog.result:
            return

        try:
            self.todo_list.update_task(
                task.task_id,
                title=dialog.result["title"],
                priority=dialog.result["priority"],
                due_date=dialog.result["due_date"] or "",   # "" = پاک‌کردن سررسید
                is_done=dialog.result["is_done"],
            )
        except ValueError as error:
            messagebox.showerror("خطای اعتبارسنجی", str(error), parent=self)
            return

        self.refresh_table()
        self.set_status(f"کار «{task.title}» ویرایش شد.", dirty=True)

    def delete_selected_task(self) -> None:
        """حذف کار انتخاب‌شده (با تأیید کاربر)."""
        task = self._selected_task()
        if task is None:
            return
        if not messagebox.askyesno("حذف کار",
                                   f"کار «{task.title}» حذف شود؟", parent=self):
            return

        self.todo_list.remove_by_id(task.task_id)
        self.refresh_table()
        self.set_status(f"کار «{task.title}» حذف شد.", dirty=True)

    def toggle_selected_task(self) -> None:
        """تغییر وضعیت انجام‌شده/انجام‌نشده‌ی کار انتخاب‌شده (دابل‌کلیک)."""
        task = self._selected_task()
        if task is None:
            return
        task.toggle_done()
        self.refresh_table()
        new_status = "انجام‌شده" if task.is_done else "انجام‌نشده"
        self.set_status(f"وضعیت «{task.title}» به {new_status} تغییر کرد.", dirty=True)

    # ------------------------------------------------------------------ #
    #                        فرم‌های جستجو و گزارش                        #
    # ------------------------------------------------------------------ #
    def _open_child(self, key: str, factory) -> None:
        """بازکردن فرم فرعی؛ اگر از قبل باز باشد، به آن فوکوس می‌دهد."""
        existing = self._child_windows.get(key)
        if existing is not None and existing.winfo_exists():
            existing.deiconify()
            existing.lift()
            existing.focus_force()
            return
        window = factory()
        self._child_windows[key] = window

    def open_search_window(self) -> None:
        """بازکردن فرم جستجو و فیلتر پیشرفته."""
        self._open_child("search", lambda: SearchWindow(self, self))

    def open_report_window(self) -> None:
        """بازکردن فرم گزارش‌گیری."""
        self._open_child("report", lambda: ReportWindow(self, self))

    def send_notification_now(self) -> None:
        """ارسال دستی اعلان برای کارهای عقب‌افتاده و موعد امروز."""
        message = self.notifier.notify_task_alerts(self.todo_list)
        if message is None:
            messagebox.showinfo("اعلان",
                                "هیچ کار عقب‌افتاده یا دارای موعد امروز وجود ندارد.",
                                parent=self)
            self.set_status("اعلان: موردی برای هشدار نبود.")
        else:
            self.set_status("اعلان هشدار ارسال شد.")

    def _startup_notification(self) -> None:
        """اعلان خودکار هنگام شروع برنامه (در صورت وجود کار عقب‌افتاده/امروز)."""
        try:
            self.notifier.notify_task_alerts(self.todo_list)
        except Exception:
            pass  # اعلان هرگز نباید اجرای برنامه را متوقف کند

    # ------------------------------------------------------------------ #
    #                        بستن برنامه                                 #
    # ------------------------------------------------------------------ #
    def _on_close(self) -> None:
        """درخواست ذخیره‌ی تغییرات در صورت خروج از برنامه."""
        if self._dirty:
            answer = messagebox.askyesnocancel(
                "خروج از برنامه",
                "تغییرات ذخیره‌نشده دارید. قبل از خروج ذخیره شود؟",
                parent=self)
            if answer is None:      # انصراف
                return
            if answer:              # بله → ذخیره
                if not self.save_data():
                    return
        self.destroy()


# === فرم ۲: افزودن / ویرایش کار =============================================
class TaskFormDialog(BaseForm):
    """فرم افزودن کار جدید یا ویرایش کار موجود (مُدال)."""

    def __init__(self, master, app: "MainWindow", task: Task | None = None):
        title = "افزودن کار جدید" if task is None else "ویرایش کار"
        super().__init__(master, app, title, resizable=False)
        self.task = task
        self.result: dict | None = None

        body = ttk.Frame(self, padding=20)
        body.pack(fill="both", expand=True)
        body.columnconfigure(1, weight=1)

        # --- عنوان ------------------------------------------------------------
        ttk.Label(body, text="عنوان کار: *", font=self.font_bold).grid(
            row=0, column=0, sticky="e", padx=(0, 10), pady=8)
        self.title_var = tk.StringVar(value=task.title if task else "")
        title_entry = ttk.Entry(body, textvariable=self.title_var, width=38)
        title_entry.grid(row=0, column=1, columnspan=3, sticky="ew", pady=8)

        # --- اولویت ------------------------------------------------------------
        ttk.Label(body, text="اولویت:").grid(row=1, column=0, sticky="e",
                                           padx=(0, 10), pady=8)
        self.priority_var = tk.StringVar(value=task.priority if task else "متوسط")
        ttk.Combobox(body, textvariable=self.priority_var, values=PRIORITIES,
                     state="readonly", width=12).grid(
            row=1, column=1, sticky="w", pady=8)
        ttk.Label(body, text="(بالا = مهم‌ترین)", foreground="#78909C").grid(
            row=1, column=2, columnspan=2, sticky="w", padx=8)

        # --- تاریخ سررسید -------------------------------------------------------
        ttk.Label(body, text="تاریخ سررسید:").grid(row=2, column=0, sticky="e",
                                                 padx=(0, 10), pady=8)
        self.due_var = tk.StringVar(value=task.due_date or "" if task else "")
        due_entry = ttk.Entry(body, textvariable=self.due_var, width=16)
        due_entry.grid(row=2, column=1, sticky="w", pady=8)

        quick = ttk.Frame(body)
        quick.grid(row=2, column=2, columnspan=2, sticky="w")
        ttk.Button(quick, text="امروز", width=7,
                   command=lambda: self.due_var.set(today_str())).pack(side="left", padx=2)
        ttk.Button(quick, text="فردا", width=7,
                   command=lambda: self.due_var.set(
                       (date.today() + timedelta(days=1)).strftime(DATE_FORMAT))
                   ).pack(side="left", padx=2)
        ttk.Button(quick, text="+۳ روز", width=7,
                   command=lambda: self.due_var.set(
                       (date.today() + timedelta(days=3)).strftime(DATE_FORMAT))
                   ).pack(side="left", padx=2)

        ttk.Label(body, text="قالب: YYYY-MM-DD (خالی = بدون سررسید)",
                  foreground="#78909C").grid(row=3, column=1, columnspan=3,
                                             sticky="w", pady=(0, 8))

        # --- وضعیت انجام --------------------------------------------------------
        self.done_var = tk.BooleanVar(value=bool(task.is_done) if task else False)
        ttk.Checkbutton(body, text="این کار انجام شده است",
                        variable=self.done_var).grid(
            row=4, column=1, columnspan=3, sticky="w", pady=4)

        # --- دکمه‌ها -------------------------------------------------------------
        buttons = ttk.Frame(body)
        buttons.grid(row=5, column=0, columnspan=4, sticky="e", pady=(16, 0))
        ttk.Button(buttons, text="ثبت", style="Accent.TButton",
                   command=self._save).pack(side="left", padx=4)
        ttk.Button(buttons, text="انصراف", command=self.destroy).pack(side="left")

        # --- رفتار پنجره ---------------------------------------------------------
        self.grab_set()                                   # مُدال
        self.bind("<Return>", lambda e: self._save())
        self.bind("<Escape>", lambda e: self.destroy())
        self.after_idle(self.center_on_parent)
        if task is None:
            self.after(10, title_entry.focus_set)

    def _save(self) -> None:
        """اعتبارسنجی ورودی‌ها و ثبت نتیجه."""
        title = self.title_var.get().strip()
        if not title:
            messagebox.showerror("خطا", "عنوان کار نمی‌تواند خالی باشد.", parent=self)
            return
        if "|" in title:
            messagebox.showerror("خطا", "عنوان کار نباید شامل کاراکتر «|» باشد.",
                                 parent=self)
            return

        due = self.due_var.get().strip()
        if due and not is_valid_date(due):
            messagebox.showerror(
                "تاریخ نامعتبر",
                "تاریخ سررسید باید با قالب YYYY-MM-DD باشد.\nمثال: 2026-11-18",
                parent=self)
            return

        self.result = {
            "title": title,
            "priority": self.priority_var.get(),
            "due_date": due or None,
            "is_done": bool(self.done_var.get()),
        }
        self.destroy()


# === فرم ۳: جستجو و فیلتر ====================================================
class SearchWindow(BaseForm):
    """فرم جستجوی پیشرفته بر اساس عنوان، تاریخ سررسید، اولویت و وضعیت."""

    def __init__(self, master, app: "MainWindow"):
        super().__init__(master, app, "جستجو و فیلتر پیشرفته", geometry="860x540")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        # --- ناحیه‌ی فیلترها -----------------------------------------------------
        filters = ttk.LabelFrame(self, text=" معیارهای جستجو ", padding=14)
        filters.grid(row=0, column=0, sticky="ew", padx=14, pady=(14, 8))
        for col in range(6):
            filters.columnconfigure(col, weight=1 if col in (1, 3) else 0)

        ttk.Label(filters, text="عنوان شامل:").grid(row=0, column=0, sticky="e", padx=4, pady=5)
        self.keyword_var = tk.StringVar()
        ttk.Entry(filters, textvariable=self.keyword_var, width=26).grid(
            row=0, column=1, sticky="ew", padx=4, pady=5)

        ttk.Label(filters, text="تاریخ سررسید:").grid(row=0, column=2, sticky="e", padx=4, pady=5)
        self.date_var = tk.StringVar()
        ttk.Entry(filters, textvariable=self.date_var, width=14).grid(
            row=0, column=3, sticky="w", padx=4, pady=5)
        ttk.Button(filters, text="امروز", width=7,
                   command=lambda: self.date_var.set(today_str())).grid(
            row=0, column=4, sticky="w", padx=4)

        ttk.Label(filters, text="اولویت:").grid(row=1, column=0, sticky="e", padx=4, pady=5)
        self.priority_var = tk.StringVar(value=ALL_PRIORITIES)
        ttk.Combobox(filters, textvariable=self.priority_var,
                     values=(ALL_PRIORITIES,) + PRIORITIES,
                     state="readonly", width=14).grid(
            row=1, column=1, sticky="w", padx=4, pady=5)

        ttk.Label(filters, text="وضعیت:").grid(row=1, column=2, sticky="e", padx=4, pady=5)
        self.status_var = tk.StringVar(value=ALL_STATUSES)
        ttk.Combobox(filters, textvariable=self.status_var,
                     values=(ALL_STATUSES, "انجام‌شده", "انجام‌نشده"),
                     state="readonly", width=14).grid(
            row=1, column=3, sticky="w", padx=4, pady=5)

        actions = ttk.Frame(filters)
        actions.grid(row=1, column=4, columnspan=2, sticky="e")
        ttk.Button(actions, text="جستجو", style="Accent.TButton",
                   command=self.run_search).pack(side="left", padx=4)
        ttk.Button(actions, text="پاک‌کردن", command=self.reset).pack(side="left", padx=4)

        # --- نتایج ---------------------------------------------------------------
        results = ttk.LabelFrame(self, text=" نتایج ", padding=10)
        results.grid(row=1, column=0, sticky="nsew", padx=14, pady=(0, 8))
        results.rowconfigure(0, weight=1)
        results.columnconfigure(0, weight=1)

        columns = ("title", "status", "priority", "due")
        self.tree = ttk.Treeview(results, columns=columns, show="headings", height=12)
        for col, text, width, anchor in (
                ("title", "عنوان کار", 400, "w"),
                ("status", "وضعیت", 110, "center"),
                ("priority", "اولویت", 100, "center"),
                ("due", "تاریخ سررسید", 160, "center")):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=width, anchor=anchor, stretch=(col == "title"))

        self.tree.tag_configure("p_بالا", background="#FDECEA", foreground="#B71C1C")
        self.tree.tag_configure("p_متوسط", background="#FFF8E1", foreground="#8D6E00")
        self.tree.tag_configure("p_پایین", background="#E8F5E9", foreground="#1B5E20")
        self.tree.tag_configure("done", background="#F5F5F5", foreground=COLOR_DONE)

        vsb = ttk.Scrollbar(results, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")

        # --- نوار پایین -----------------------------------------------------------
        bottom = ttk.Frame(self, padding=(14, 0, 14, 12))
        bottom.grid(row=2, column=0, sticky="ew")
        self.result_var = tk.StringVar(value="برای شروع، معیارها را وارد و «جستجو» را بزنید.")
        ttk.Label(bottom, textvariable=self.result_var,
                  foreground="#37474F").pack(side="left")
        ttk.Button(bottom, text="بستن", command=self.destroy).pack(side="right")

        self.after_idle(self.center_on_parent)

    def run_search(self) -> None:
        """اجرای جستجو با معیارهای واردشده."""
        target_date = self.date_var.get().strip()
        if target_date and not is_valid_date(target_date):
            messagebox.showerror(
                "تاریخ نامعتبر",
                "تاریخ باید با قالب YYYY-MM-DD وارد شود.\nمثال: 2026-11-18",
                parent=self)
            return

        priority = self.priority_var.get()
        status = self.status_var.get()

        try:
            tasks = self.app.todo_list.search_filter(
                keyword=self.keyword_var.get(),
                target_date=target_date or None,
                priority=priority if priority in PRIORITIES else None,
                status=status if status in ("انجام‌شده", "انجام‌نشده") else None,
            )
        except ValueError as error:
            messagebox.showerror("خطا", str(error), parent=self)
            return

        for item in self.tree.get_children():
            self.tree.delete(item)

        for task in tasks:
            tags = ("done",) if task.is_done else (f"p_{task.priority}",)
            self.tree.insert("", "end", iid=task.task_id, tags=tags,
                             values=(task.title, task.status_text, task.priority,
                                     task.due_date or "—"))

        self.result_var.set(f"{len(tasks)} نتیجه یافت شد.")

    def reset(self) -> None:
        """پاک‌کردن همه‌ی معیارها و نتایج."""
        self.keyword_var.set("")
        self.date_var.set("")
        self.priority_var.set(ALL_PRIORITIES)
        self.status_var.set(ALL_STATUSES)
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.result_var.set("فرم جستجو پاک شد.")


# === فرم ۴: گزارش‌گیری ========================================================
class ReportWindow(BaseForm):
    """فرم گزارش‌گیری برای یک روز خاص یا یک بازه‌ی زمانی + خروجی/کپی/چاپ."""

    PERIOD_DAY = "یک روز خاص"
    PERIOD_RANGE = "یک بازه زمانی"
    PERIOD_LAST7 = "۷ روز اخیر"
    PERIOD_NEXT7 = "۷ روز آینده"
    PERIOD_ALL = "همه کارها"
    PERIODS = (PERIOD_DAY, PERIOD_RANGE, PERIOD_LAST7, PERIOD_NEXT7, PERIOD_ALL)

    def __init__(self, master, app: "MainWindow"):
        super().__init__(master, app, "گزارش‌گیری", geometry="880x620")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        self._last_report_date = today_str()

        # --- تنظیمات گزارش -------------------------------------------------------
        settings = ttk.LabelFrame(self, text=" تنظیمات گزارش ", padding=14)
        settings.grid(row=0, column=0, sticky="ew", padx=14, pady=(14, 6))

        ttk.Label(settings, text="نوع گزارش:").grid(row=0, column=0, sticky="e", padx=4)
        self.period_var = tk.StringVar(value=self.PERIOD_DAY)
        period_box = ttk.Combobox(settings, textvariable=self.period_var,
                                  values=self.PERIODS, state="readonly", width=16)
        period_box.grid(row=0, column=1, sticky="w", padx=4)
        period_box.bind("<<ComboboxSelected>>", lambda e: self._on_period_change())

        ttk.Label(settings, text="از تاریخ:").grid(row=0, column=2, sticky="e", padx=(18, 4))
        self.start_var = tk.StringVar(value=today_str())
        self.start_entry = ttk.Entry(settings, textvariable=self.start_var, width=14)
        self.start_entry.grid(row=0, column=3, sticky="w", padx=4)

        ttk.Label(settings, text="تا تاریخ:").grid(row=0, column=4, sticky="e", padx=(12, 4))
        self.end_var = tk.StringVar(value=today_str())
        self.end_entry = ttk.Entry(settings, textvariable=self.end_var, width=14)
        self.end_entry.grid(row=0, column=5, sticky="w", padx=4)

        actions = ttk.Frame(settings)
        actions.grid(row=0, column=6, sticky="e", padx=(18, 0))
        ttk.Button(actions, text="تولید گزارش", style="Accent.TButton",
                   command=self.generate_report).pack(side="left", padx=3)
        ttk.Button(actions, text="امروز", width=7,
                   command=self._set_today).pack(side="left", padx=3)

        ttk.Label(settings, text="قالب تاریخ: YYYY-MM-DD",
                  foreground="#78909C").grid(row=1, column=0, columnspan=7,
                                             sticky="w", pady=(8, 0))

        # --- متن گزارش -------------------------------------------------------------
        text_frame = ttk.LabelFrame(self, text=" پیش‌نمایش گزارش ", padding=8)
        text_frame.grid(row=2, column=0, sticky="nsew", padx=14, pady=6)
        text_frame.rowconfigure(0, weight=1)
        text_frame.columnconfigure(0, weight=1)

        self.report_view = ScrollableTextFrame(
            text_frame, font_tuple=(self.font_family, self.font_size))
        self.report_view.grid(row=0, column=0, sticky="nsew")

        # --- نوار دکمه‌ها -----------------------------------------------------------
        bottom = ttk.Frame(self, padding=(14, 4, 14, 12))
        bottom.grid(row=3, column=0, sticky="ew")

        ttk.Button(bottom, text="ذخیره در فایل",
                   command=self.save_report_file).pack(side="left", padx=3)
        ttk.Button(bottom, text="کپی متن",
                   command=self.copy_report).pack(side="left", padx=3)
        ttk.Button(bottom, text="چاپ",
                   command=self.print_report).pack(side="left", padx=3)

        self.status_var = tk.StringVar(value="")
        ttk.Label(bottom, textvariable=self.status_var,
                  foreground="#455A64").pack(side="left", padx=12)

        ttk.Button(bottom, text="بستن", command=self.destroy).pack(side="right")

        self._on_period_change()
        self.generate_report()
        self.after_idle(self.center_on_parent)

    # --- تغییر نوع گزارش --------------------------------------------------------
    def _on_period_change(self) -> None:
        """فعال/غیرفعال کردن فیلدهای تاریخ بر اساس نوع گزارش."""
        period = self.period_var.get()
        if period == self.PERIOD_LAST7:
            start, end = last_7_days_range()
            self.start_var.set(start)
            self.end_var.set(end)
        elif period == self.PERIOD_NEXT7:
            start, end = next_7_days_range()
            self.start_var.set(start)
            self.end_var.set(end)
        elif period == self.PERIOD_ALL:
            self.start_var.set("")
            self.end_var.set("")

        state = "normal" if period in (self.PERIOD_DAY, self.PERIOD_RANGE) else "disabled"
        self.start_entry.configure(state=state)
        self.end_entry.configure(state=state)

    def _set_today(self) -> None:
        """تنظیم تاریخ‌ها روی امروز."""
        self.start_var.set(today_str())
        self.end_var.set(today_str())

    # --- تولید گزارش --------------------------------------------------------------
    def generate_report(self) -> None:
        """تولید متن گزارش بر اساس نوع انتخاب‌شده."""
        period = self.period_var.get()
        start = self.start_var.get().strip()
        end = self.end_var.get().strip()

        try:
            if period == self.PERIOD_DAY:
                if not is_valid_date(start):
                    messagebox.showerror("تاریخ نامعتبر",
                                         "تاریخ گزارش را با قالب YYYY-MM-DD وارد کنید.",
                                         parent=self)
                    return
                text = report_for_date(self.app.todo_list, start)
                count = len(self.app.todo_list.list_by_date(start))
                self._last_report_date = start

            elif period == self.PERIOD_RANGE:
                if not is_valid_date(start) or not is_valid_date(end):
                    messagebox.showerror("تاریخ نامعتبر",
                                         "تاریخ شروع و پایان باید قالب YYYY-MM-DD داشته باشند.",
                                         parent=self)
                    return
                tasks = self.app.todo_list.list_in_range(start, end)
                text = build_range_report(tasks, start, end)
                count = len(tasks)
                self._last_report_date = start

            elif period == self.PERIOD_LAST7:
                start, end = last_7_days_range()
                tasks = self.app.todo_list.list_in_range(start, end)
                text = build_range_report(tasks, start, end)
                count = len(tasks)
                self._last_report_date = today_str()

            elif period == self.PERIOD_NEXT7:
                start, end = next_7_days_range()
                tasks = self.app.todo_list.list_in_range(start, end)
                text = build_range_report(tasks, start, end)
                count = len(tasks)
                self._last_report_date = today_str()

            else:  # همه کارها
                text = build_full_report(self.app.todo_list)
                count = len(self.app.todo_list)
                self._last_report_date = today_str()

        except ValueError as error:
            messagebox.showerror("خطای گزارش", str(error), parent=self)
            return

        self.report_view.set_text(text)
        self.status_var.set(f"گزارش با {count} کار تولید شد.")

    # --- خروجی‌ها -------------------------------------------------------------------
    def save_report_file(self) -> None:
        """ذخیره‌ی گزارش در فایل متنی با انتخاب کاربر."""
        text = self.report_view.get_text().strip()
        if not text:
            messagebox.showwarning("گزارش خالی",
                                   "ابتدا گزارش را تولید کنید.", parent=self)
            return

        filepath = filedialog.asksaveasfilename(
            parent=self,
            title="ذخیره‌ی گزارش",
            initialfile=default_report_filename(self._last_report_date),
            defaultextension=".txt",
            filetypes=[("فایل متنی", "*.txt"), ("همه فایل‌ها", "*.*")],
        )
        if not filepath:
            return

        try:
            saved_path = save_report(text, filepath)
        except OSError as error:
            messagebox.showerror("خطا در ذخیره",
                                 f"نوشتن فایل ممکن نشد:\n{error}", parent=self)
            return

        self.status_var.set(f"گزارش در «{os.path.basename(saved_path)}» ذخیره شد.")
        messagebox.showinfo("ذخیره شد",
                            f"گزارش با موفقیت ذخیره شد:\n{saved_path}", parent=self)

    def copy_report(self) -> None:
        """کپی متن گزارش در کلیپ‌بورد."""
        text = self.report_view.get_text().strip()
        if not text:
            messagebox.showwarning("گزارش خالی",
                                   "ابتدا گزارش را تولید کنید.", parent=self)
            return
        copy_to_clipboard(self, text)
        self.status_var.set("متن گزارش در کلیپ‌بورد کپی شد.")

    def print_report(self) -> None:
        """چاپ گزارش با چاپگر پیش‌فرض سیستم (در صورت پشتیبانی سیستم‌عامل).

        * ویندوز: ارسال فایل به چاپگر پیش‌فرض با os.startfile(..., "print")
        * لینوکس/مک: استفاده از دستور lp در صورت وجود
        * در غیر این صورت: فایل موقت ساخته می‌شود و به کاربر اطلاع داده می‌شود.
        """
        text = self.report_view.get_text().strip()
        if not text:
            messagebox.showwarning("گزارش خالی",
                                   "ابتدا گزارش را تولید کنید.", parent=self)
            return

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        temp_path = Path(tempfile.gettempdir()) / f"todo_report_{stamp}.txt"
        try:
            temp_path.write_text(text, encoding="utf-8")
        except OSError as error:
            messagebox.showerror("خطا", f"ساخت فایل موقت ممکن نشد:\n{error}",
                                 parent=self)
            return

        try:
            if sys.platform.startswith("win"):
                os.startfile(str(temp_path), "print")   # type: ignore[attr-defined]
                self.status_var.set("گزارش به چاپگر پیش‌فرض ارسال شد.")
                return

            lp_command = shutil.which("lp")
            if lp_command:
                subprocess.run([lp_command, str(temp_path)], check=True)
                self.status_var.set("گزارش به صف چاپ ارسال شد.")
                return
        except (OSError, subprocess.SubprocessError) as error:
            messagebox.showerror("خطا در چاپ", f"چاپ گزارش ممکن نشد:\n{error}",
                                 parent=self)
            return

        # --- نسخه‌ی جایگزین: چاپگر سیستمی پیدا نشد -----------------------------
        messagebox.showinfo(
            "چاپ گزارش",
            "چاپگر سیستمی یافت نشد یا پشتیبانی نمی‌شود.\n"
            "می‌توانید گزارش را با دکمه‌ی «ذخیره در فایل» ذخیره کرده و "
            "سپس با هر برنامه‌ای (مثل Notepad) چاپ کنید.\n\n"
            f"نسخه‌ی موقت در این مسیر ذخیره شد:\n{temp_path}",
            parent=self,
        )
        self.status_var.set("چاپگر یافت نشد؛ فایل موقت گزارش ساخته شد.")


# === اجرای برنامه =============================================================
def main() -> None:
    """نقطه‌ی شروع برنامه."""
    try:
        app = MainWindow()
    except tk.TclError as error:
        print("خطا: نمایشگر گرافیکی در دسترس نیست (این برنامه نیاز به محیط گرافیکی دارد).")
        print(f"جزئیات: {error}")
        return

    app.mainloop()


if __name__ == "__main__":
    main()
