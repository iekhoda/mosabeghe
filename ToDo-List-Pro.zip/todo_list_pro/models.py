# -*- coding: utf-8 -*-
"""
models.py
===========================================================================
پروژه  : نرم‌افزار مدیریت پیشرفته لیست کارهای روزانه (To-Do List Pro)
نویسنده: (نام و نام خانوادگی شما)
بخش    : لایه‌ی داده‌ها (Model Layer)
---------------------------------------------------------------------------
این فایل شامل دو کلاس اصلی ساختار داده است:

    1) Task      : مدل یک «کار/تسک» شامل عنوان، وضعیت انجام، اولویت،
                   تاریخ ایجاد و تاریخ سررسید.
    2) TodoList  : مدیر مجموعه‌ی تسک‌ها شامل افزودن، حذف، ویرایش،
                   جستجو، فیلتر و ذخیره/بازیابی در فایل متنی.

نکته‌ی طراحی:
    کلاس TodoList هیچ وابستگی‌ای به رابط گرافیکی (Tkinter) ندارد؛
    بنابراین لایه‌ی داده کاملاً مستقل و قابل تست است. (اصل Separation of Concerns)
===========================================================================
"""

from __future__ import annotations

# --- واردسازی کتابخانه‌های استاندارد ---------------------------------------
import os
import hashlib
from datetime import datetime, date


# === ثابت‌های سراسری =======================================================
#: اولویت‌های مجاز به‌ترتیب اهمیت (کم‌ترین مقدار عددی = مهم‌ترین)
PRIORITIES = ("بالا", "متوسط", "پایین")
PRIORITY_LEVEL = {name: index for index, name in enumerate(PRIORITIES)}  # بالا=0، متوسط=1، پایین=2

DATE_FORMAT = "%Y-%m-%d"                       # قالب استاندارد تاریخ
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"          # قالب استاندارد تاریخ و ساعت
FILE_SEPARATOR = "|"                           # جداکننده‌ی فیلدها در فایل متنی
FILE_HEADER = "# todo_list_pro v1 | فایل ذخیره‌سازی تسک‌ها (فرمت: id|title|is_done|priority|created_date|due_date)"


def normalize_priority(priority: str) -> str:
    """اولویت ورودی را اعتبارسنجی می‌کند و آن را به یکی از مقادیر مجاز برمی‌گرداند.

    اگر مقدار ورودی نامعتبر باشد، به‌صورت پیش‌فرض «متوسط» در نظر گرفته می‌شود.
    """
    text = str(priority or "").strip()
    return text if text in PRIORITIES else "متوسط"


class Task:
    """مدل یک تسک (کار روزانه).

    ویژگی‌ها:
        title        (str)  : عنوان کار                (اجباری)
        is_done      (bool) : وضعیت انجام شدن          (پیش‌فرض: False)
        priority     (str)  : اولویت («بالا»/«متوسط»/«پایین»، پیش‌فرض: «متوسط»)
        created_date (datetime): تاریخ و ساعت ایجاد (به‌صورت خودکار در سازنده ثبت می‌شود)
        due_date     (str)  : تاریخ سررسید به قالب YYYY-MM-DD (یا None)
        task_id      (str)  : شناسه‌ی یکتا برای تشخیص مطمئن تسک‌ها در رابط گرافیکی
    """

    def __init__(self, title: str, priority: str = "متوسط",
                 due_date: str | None = None,
                 is_done: bool = False,
                 created_date: datetime | None = None,
                 task_id: str | None = None):
        # --- عنوان: نباید خالی باشد ----------------------------------------
        title = str(title or "").strip()
        if not title:
            raise ValueError("عنوان تسک نمی‌تواند خالی باشد.")

        # --- جلوگیری از ورود کاراکتر جداکننده (خراب‌شدن ساختار فایل) --------
        if FILE_SEPARATOR in title:
            raise ValueError(f"عنوان تسک نباید شامل کاراکتر «{FILE_SEPARATOR}» باشد.")

        self.title = title
        self.is_done = bool(is_done)
        self.priority = normalize_priority(priority)

        # --- ثبت خودکار تاریخ ایجاد ----------------------------------------
        # اگر تسکی از فایل خوانده شود، تاریخ ایجادِ ذخیره‌شده حفظ می‌شود؛
        # در غیر این صورت از تاریخ و ساعت لحظه‌ی اجرا استفاده می‌کنیم.
        # میکروثانیه حذف می‌شود تا ذخیره/بازیابی در فایل دقیقاً یکسان باشد.
        self.created_date: datetime = (created_date if created_date else datetime.now()).replace(microsecond=0)

        # --- تاریخ سررسید: فقط قالب صحیح پذیرفته می‌شود ----------------------
        self.due_date: str | None = None
        if due_date:
            self.due_date = self.validate_date(due_date)

        # --- شناسه‌ی یکتا ---------------------------------------------------
        # بر پایه‌ی زمان دقیق (تا میکروثانیه) + هش عنوان تولید می‌شود تا در
        # فایل‌هایی که چند تسک هم‌نام دارند هم شناسه‌ها تکراری نشوند.
        self.task_id: str = task_id or self._generate_id(self.title)

    # ------------------------------------------------------------------ #
    #                        ویژگی‌ها و متدهای کمکی                       #
    # ------------------------------------------------------------------ #
    @staticmethod
    def _generate_id(title: str) -> str:
        """تولید شناسه‌ی یکتا بر اساس زمان جاری و درهم‌سازی عنوان."""
        seed = f"{datetime.now().isoformat()}|{title}".encode("utf-8")
        return hashlib.md5(seed).hexdigest()[:12]

    @staticmethod
    def validate_date(value: str) -> str:
        """اعتبارسنجی تاریخ با قالب YYYY-MM-DD و بازگرداندن آن به‌شکل استاندارد.

        در صورت نامعتبر بودن تاریخ، خطای ValueError با پیام فارسی صادر می‌شود.
        """
        value = str(value or "").strip()
        try:
            return datetime.strptime(value, DATE_FORMAT).strftime(DATE_FORMAT)
        except ValueError:
            raise ValueError(f"تاریخ «{value}» معتبر نیست. قالب صحیح: YYYY-MM-DD (مثال: 2026-11-18)")

    @property
    def status_text(self) -> str:
        """متن فارسی وضعیت تسک برای نمایش در جدول و گزارش‌ها."""
        return "انجام‌شده" if self.is_done else "انجام‌نشده"

    @property
    def created_date_str(self) -> str:
        """تاریخ ایجاد به‌صورت رشته (سال-ماه-روز ساعت:دقیقه)."""
        return self.created_date.strftime("%Y-%m-%d %H:%M")

    @property
    def priority_rank(self) -> int:
        """رتبه‌ی عددی اولویت (برای مرتب‌سازی؛ عدد کمتر = مهم‌تر)."""
        return PRIORITY_LEVEL.get(self.priority, 1)

    def mark_done(self, done: bool = True) -> None:
        """تغییر وضعیت انجام شدن تسک."""
        self.is_done = bool(done)

    def toggle_done(self) -> None:
        """وارونه‌کردن وضعیت انجام شدن تسک (برای دکمه‌ی «تغییر وضعیت»)."""
        self.is_done = not self.is_done

    def is_overdue(self, today: date | None = None) -> bool:
        """آیا تسک عقب‌افتاده است؟ (سررسید گذشته و هنوز انجام نشده)"""
        if self.is_done or not self.due_date:
            return False
        reference = today or date.today()
        return datetime.strptime(self.due_date, DATE_FORMAT).date() < reference

    def is_due_today(self, today: date | None = None) -> bool:
        """آیا سررسید تسک دقیقاً امروز است؟"""
        if not self.due_date:
            return False
        reference = today or date.today()
        return datetime.strptime(self.due_date, DATE_FORMAT).date() == reference

    def days_left(self, today: date | None = None) -> int | None:
        """تعداد روز باقی‌مانده تا سررسید (منفی = تعداد روزهای تأخیر)."""
        if not self.due_date:
            return None
        reference = today or date.today()
        return (datetime.strptime(self.due_date, DATE_FORMAT).date() - reference).days

    # ------------------------------------------------------------------ #
    #                      تبدیل به / از خط فایل متنی                     #
    # ------------------------------------------------------------------ #
    def to_file_line(self) -> str:
        """تبدیل تسک به یک خط متنی برای ذخیره در data.txt.

        قالب:  id|title|is_done|priority|created_date|due_date
        مثال:  428def0b3a6c|ورزش صبحگاهی|0|بالا|2026-11-18 09:30:00|2026-11-20
        """
        return FILE_SEPARATOR.join([
            self.task_id,
            self.title,
            "1" if self.is_done else "0",
            self.priority,
            self.created_date.strftime(DATETIME_FORMAT),
            self.due_date or "",
        ])

    @classmethod
    def from_file_line(cls, line: str) -> "Task":
        """ساخت یک شیء Task از یک خط فایل؛ در صورت خرابی خط، ValueError صادر می‌شود."""
        parts = line.rstrip("\n").split(FILE_SEPARATOR)
        if len(parts) != 6:
            raise ValueError(f"خط فایل نامعتبر است (تعداد فیلدها = {len(parts)}): {line!r}")

        task_id, title, done_flag, priority, created_raw, due_raw = parts

        # تاریخ ایجاد ممکن است خالی باشد (فایل‌های دست‌ساز) → زمان حال
        try:
            created = datetime.strptime(created_raw.strip(), DATETIME_FORMAT) \
                if created_raw.strip() else datetime.now()
        except ValueError:
            created = datetime.now()

        return cls(
            title=title,
            priority=priority,
            due_date=due_raw.strip() or None,
            is_done=(done_flag.strip() == "1"),
            created_date=created,
            task_id=task_id.strip() or None,
        )

    def to_dict(self) -> dict:
        """خروجی دیکشنری (برای استفاده‌های آینده مانند JSON یا API)."""
        return {
            "task_id": self.task_id,
            "title": self.title,
            "is_done": self.is_done,
            "priority": self.priority,
            "created_date": self.created_date.strftime(DATETIME_FORMAT),
            "due_date": self.due_date,
        }

    def __repr__(self) -> str:
        return (f"Task(id={self.task_id!r}, title={self.title!r}, "
                f"is_done={self.is_done}, priority={self.priority!r}, "
                f"due_date={self.due_date!r})")


class TodoList:
    """مدیر مجموعه‌ی تسک‌ها (مدل اصلی برنامه).

    وظایف:
        * افزودن / حذف / ویرایش تسک‌ها
        * فهرست‌کردن، مرتب‌سازی و فیلتر کردن تسک‌ها بر اساس تاریخ و اولویت
        * ذخیره و بازیابی خودکار در فایل متنی (data.txt)
    """

    def __init__(self):
        self.tasks: list[Task] = []

    # ------------------------------------------------------------------ #
    #                      عملیات اصلی (CRUD)                            #
    # ------------------------------------------------------------------ #
    def add_task(self, task: Task) -> Task:
        """افزودن یک تسک به لیست و بازگرداندن همان تسک."""
        if not isinstance(task, Task):
            raise TypeError("فقط شیء از کلاس Task قابل افزودن است.")
        self.tasks.append(task)
        return task

    def remove_task(self, title: str) -> bool:
        """حذف تسک بر اساس عنوان.

        خروجی: True اگر حداقل یک تسک حذف شود، در غیر این صورت False.
        (اگر چند تسک هم‌نام باشند، همه حذف می‌شوند.)
        """
        title_stripped = str(title or "").strip()
        before = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.title != title_stripped]
        return len(self.tasks) < before

    def remove_by_id(self, task_id: str) -> bool:
        """حذف تسک بر اساس شناسه‌ی یکتا (روش مطمئن‌تر برای رابط گرافیکی)."""
        before = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.task_id != task_id]
        return len(self.tasks) < before

    def get_by_id(self, task_id: str) -> Task | None:
        """یافتن تسک با شناسه؛ در صورت نبود، None برمی‌گردد."""
        for task in self.tasks:
            if task.task_id == task_id:
                return task
        return None

    def find_by_title(self, title: str) -> list[Task]:
        """یافتن همه‌ی تسک‌هایی که عنوانشان دقیقاً برابر مقدار داده‌شده است."""
        return [t for t in self.tasks if t.title == str(title or "").strip()]

    def update_task(self, task_id: str, title: str | None = None,
                    priority: str | None = None,
                    due_date: str | None = None,
                    is_done: bool | None = None) -> Task:
        """ویرایش فیلدهای یک تسک موجود و بازگرداندن آن.

        فقط فیلدهایی که مقدار غیر None دارند تغییر می‌کنند.
        (برای پاک‌کردن سررسید، مقدار "" را ارسال کنید.)
        """
        task = self.get_by_id(task_id)
        if task is None:
            raise ValueError("تسکی با این شناسه یافت نشد.")

        if title is not None:
            new_title = str(title).strip()
            if not new_title:
                raise ValueError("عنوان تسک نمی‌تواند خالی باشد.")
            if FILE_SEPARATOR in new_title:
                raise ValueError(f"عنوان تسک نباید شامل کاراکتر «{FILE_SEPARATOR}» باشد.")
            task.title = new_title

        if priority is not None:
            task.priority = normalize_priority(priority)

        if due_date is not None:
            task.due_date = Task.validate_date(due_date) if str(due_date).strip() else None

        if is_done is not None:
            task.is_done = bool(is_done)

        return task

    # ------------------------------------------------------------------ #
    #                        فهرست‌کردن و فیلتر                          #
    # ------------------------------------------------------------------ #
    def list_tasks(self, sort: bool = True) -> list[Task]:
        """بازگرداندن فهرست تسک‌ها.

        اگر sort=True باشد، ابتدا «انجام‌نشده‌ها» سپس «انجام‌شده‌ها» و
        در هر گروه بر اساس اولویت (بالا→پایین) و پس از آن تاریخ سررسید
        مرتب می‌شوند.
        """
        return self._sorted(self.tasks) if sort else list(self.tasks)

    @staticmethod
    def _sorted(items: list[Task]) -> list[Task]:
        """مرتب‌سازی استاندارد: وضعیت انجام → اولویت → تاریخ سررسید → عنوان."""
        return sorted(
            items,
            key=lambda t: (
                t.is_done,                       # انجام‌نشده‌ها بالا
                t.priority_rank,                 # بالا، متوسط، پایین
                t.due_date or "9999-12-31",      # بدون سررسید در انتها
                t.title,
            ),
        )

    def list_by_date(self, target_date: str) -> list[Task]:
        """فیلتر تسک‌هایی که تاریخ سررسیدشان برابر target_date (YYYY-MM-DD) است."""
        target = Task.validate_date(target_date)
        return self._sorted([t for t in self.tasks if t.due_date == target])

    def list_by_priority(self, priority: str) -> list[Task]:
        """فیلتر تسک‌ها بر اساس اولویت."""
        return self._sorted([t for t in self.tasks if t.priority == normalize_priority(priority)])

    def list_by_status(self, is_done: bool) -> list[Task]:
        """فیلتر تسک‌های انجام‌شده / انجام‌نشده."""
        return self._sorted([t for t in self.tasks if t.is_done == bool(is_done)])

    def list_in_range(self, start_date: str, end_date: str) -> list[Task]:
        """فیلتر تسک‌هایی که سررسیدشان در بازه‌ی [start_date, end_date] است."""
        start = datetime.strptime(Task.validate_date(start_date), DATE_FORMAT).date()
        end = datetime.strptime(Task.validate_date(end_date), DATE_FORMAT).date()
        if start > end:
            raise ValueError("تاریخ شروع نمی‌تواند بعد از تاریخ پایان باشد.")
        result = []
        for t in self.tasks:
            if not t.due_date:
                continue
            d = datetime.strptime(t.due_date, DATE_FORMAT).date()
            if start <= d <= end:
                result.append(t)
        return self._sorted(result)

    def search(self, keyword: str) -> list[Task]:
        """جستجوی متنی (غیرحساس به بزرگی/کوچکی حروف) در عنوان تسک‌ها."""
        needle = str(keyword or "").strip().lower()
        if not needle:
            return self.list_tasks()
        return self._sorted([t for t in self.tasks if needle in t.title.lower()])

    def search_filter(self, keyword: str = "", target_date: str | None = None,
                      priority: str | None = None,
                      status: str | None = None) -> list[Task]:
        """جستجوی پیشرفته‌ی ترکیبی (عنوان + تاریخ + اولویت + وضعیت).

        پارامترها:
            keyword     : بخشی از عنوان (خالی = بدون فیلتر)
            target_date : تاریخ سررسید به قالب YYYY-MM-DD (None = بدون فیلتر)
            priority    : یکی از PRIORITIES (None = بدون فیلتر)
            status      : "انجام‌شده" | "انجام‌نشده" | None
        """
        result = self.tasks

        if keyword and keyword.strip():
            needle = keyword.strip().lower()
            result = [t for t in result if needle in t.title.lower()]

        if target_date:
            target = Task.validate_date(target_date)
            result = [t for t in result if t.due_date == target]

        if priority and priority in PRIORITIES:
            result = [t for t in result if t.priority == priority]

        if status == "انجام‌شده":
            result = [t for t in result if t.is_done]
        elif status == "انجام‌نشده":
            result = [t for t in result if not t.is_done]

        return self._sorted(result)

    def overdue_tasks(self, today: date | None = None) -> list[Task]:
        """تسک‌های عقب‌افتاده (سررسید گذشته و انجام‌نشده)."""
        return self._sorted([t for t in self.tasks if t.is_overdue(today)])

    def today_tasks(self, today: date | None = None) -> list[Task]:
        """تسک‌هایی که سررسیدشان امروز است."""
        return self._sorted([t for t in self.tasks if t.is_due_today(today)])

    def statistics(self) -> dict:
        """آمار کلی برای نمایش در فرم اصلی و گزارش‌ها."""
        total = len(self.tasks)
        done = sum(1 for t in self.tasks if t.is_done)
        return {
            "total": total,
            "done": done,
            "pending": total - done,
            "overdue": len(self.overdue_tasks()),
            "today": len(self.today_tasks()),
        }

    # ------------------------------------------------------------------ #
    #                     ذخیره‌سازی و بازیابی فایل                      #
    # ------------------------------------------------------------------ #
    def save_to_file(self, filename: str = "data.txt") -> int:
        """ذخیره‌ی همه‌ی تسک‌ها در فایل متنی و بازگرداندن تعداد تسک‌های ذخیره‌شده.

        ساختار فایل:
            خط ۱ : عنوان/کامنت فرمت فایل (با # شروع می‌شود و نادیده گرفته می‌شود)
            خطوط بعد : یک تسک در هر خط به قالب «id|title|is_done|priority|created|due»
        """
        lines = [FILE_HEADER]
        lines += [task.to_file_line() for task in self.tasks]
        content = "\n".join(lines) + "\n"

        with open(filename, "w", encoding="utf-8") as file:
            file.write(content)
        return len(self.tasks)

    def load_from_file(self, filename: str = "data.txt") -> int:
        """بازیابی تسک‌ها از فایل متنی و بازگرداندن تعداد تسک‌های خوانده‌شده.

        * اگر فایل وجود نداشته باشد، لیست خالی می‌ماند (خطا صادر نمی‌شود).
        * خطوط خالی، کامنت‌ها (شروع با #) و خطوط خراب نادیده گرفته می‌شوند
          تا یک خط خراب کل برنامه را از کار نیندازد.
        """
        self.tasks = []
        if not os.path.exists(filename):
            return 0

        count = 0
        with open(filename, "r", encoding="utf-8") as file:
            for raw_line in file:
                line = raw_line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    self.tasks.append(Task.from_file_line(line))
                    count += 1
                except (ValueError, TypeError):
                    # خط خراب → رد شود و ادامه‌ی خواندن متوقف نشود
                    continue
        return count

    def __len__(self) -> int:
        return len(self.tasks)
