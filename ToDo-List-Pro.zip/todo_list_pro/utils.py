# -*- coding: utf-8 -*-
"""
utils.py
===========================================================================
پروژه  : نرم‌افزار مدیریت پیشرفته لیست کارهای روزانه (To-Do List Pro)
بخش    : توابع کمکی (Utility Layer)
---------------------------------------------------------------------------
این فایل شامل ابزارهای عمومی و مستقل از رابط گرافیکی است:

    * توابع تاریخ و ساعت (نمایش تاریخ و ساعت سیستم، اعتبارسنجی تاریخ، ...)
    * ساخت گزارش متنی طبق قالب استاندارد مسابقه:
          تاریخ: YYYY-MM-DD
          ----------------------------------------
          - عنوان: [...] | وضعیت: [...] | اولویت: [...]
    * محاسبه‌ی آمار روزانه (درصد پیشرفت)
    * ارسال اعلان (Notification) با کتابخانه‌ی plyer و جایگزین Tkinter
    * ابزارهای کوچک UI مانند انتخاب فونت فارسی و کپی متن در کلیپ‌بورد
===========================================================================
"""

from __future__ import annotations

# --- کتابخانه‌های استاندارد -------------------------------------------------
from datetime import datetime, date, timedelta
from pathlib import Path

# --- واردسازی مدل‌ها (بدون وابستگی به Tkinter) ------------------------------
from models import Task, TodoList, DATE_FORMAT

# --- تلاش برای واردسازی plyer (اختیاری؛ در صورت نبود، جایگزین می‌شود) --------
try:
    from plyer import notification as _plyer_notification
    PLYER_AVAILABLE = True
except Exception:          # ImportError و هر خطای محیطی دیگر
    _plyer_notification = None
    PLYER_AVAILABLE = False


# === ۱) توابع تاریخ و ساعت ==================================================
def now() -> datetime:
    """تاریخ و ساعت جاری سیستم."""
    return datetime.now()


def today_str() -> str:
    """امروز به قالب YYYY-MM-DD."""
    return date.today().strftime(DATE_FORMAT)


def now_str() -> str:
    """تاریخ و ساعت جاری سیستم به‌صورت رشته‌ی خوانا (برای نوار وضعیت)."""
    return datetime.now().strftime("%Y-%m-%d  %H:%M:%S")


def format_persian_date(dt: datetime | None = None) -> str:
    """تاریخ جاری به شکل «چهارشنبه ۱۸ نوامبر ۲۰۲۶».

    (نام روز و نام ماه به فارسی؛ معادل‌سازی تقویمی انجام نمی‌شود و همان
    تاریخ میلادی سیستم با الفبای فارسی نمایش داده می‌شود.)
    """
    dt = dt or datetime.now()
    week_days = ["دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه"]
    months = ["ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن",
              "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"]
    to_fa = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
    text = f"{week_days[dt.weekday()]} {dt.day} {months[dt.month - 1]} {dt.year}"
    return text.translate(to_fa)


def format_persian_datetime(dt: datetime | None = None) -> str:
    """تاریخ و ساعت جاری به شکل «چهارشنبه ۱۸ نوامبر ۲۰۲۶ — ۱۴:۳۰:۲۵»."""
    dt = dt or datetime.now()
    to_fa = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
    return f"{format_persian_date(dt)} — {dt.strftime('%H:%M:%S').translate(to_fa)}"


def is_valid_date(value: str) -> bool:
    """آیا رشته، یک تاریخ معتبر با قالب YYYY-MM-DD است؟"""
    try:
        datetime.strptime(str(value).strip(), DATE_FORMAT)
        return True
    except (ValueError, TypeError):
        return False


def days_until(target_date: str) -> int:
    """تعداد روز باقی‌مانده تا target_date (منفی = گذشته)."""
    return (datetime.strptime(target_date, DATE_FORMAT).date() - date.today()).days


def relative_due_text(task: Task) -> str:
    """متن نسبی سررسید برای ستون «سررسید» جدول.

    مثال‌ها: «امروز»، «فردا»، «۲ روز مانده»، «۳ روز تأخیر» یا رشته‌ی خالی.
    """
    if not task.due_date:
        return ""
    remaining = days_until(task.due_date)
    if task.is_done:
        return task.due_date
    if remaining == 0:
        return f"{task.due_date} (امروز)"
    if remaining == 1:
        return f"{task.due_date} (فردا)"
    if remaining > 1:
        return f"{task.due_date} ({remaining} روز مانده)"
    return f"{task.due_date} ({abs(remaining)} روز تأخیر)"


# === ۲) ساخت گزارش متنی (قالب استاندارد مسابقه) ============================
REPORT_SEPARATOR = "----------------------------------------"
REPORT_HEADER_TEMPLATE = "تاریخ: {date}"
REPORT_ITEM_TEMPLATE = "- عنوان: [{title}] | وضعیت: [{status}] | اولویت: [{priority}]"


def build_daily_report(tasks: list[Task], report_date: str, title: str | None = None) -> str:
    """ساخت گزارش متنی تسک‌های یک روز خاص با قالب دقیق استاندارد:

        تاریخ: 2026-11-18
        ----------------------------------------
        - عنوان: [انجام تکالیف] | وضعیت: [انجام‌نشده] | اولویت: [بالا]

    پارامترها:
        tasks       : فهرست تسک‌های همان روز
        report_date : تاریخ گزارش به قالب YYYY-MM-DD
        title       : عنوان اختیاری گزارش؛ اگر None باشد (پیش‌فرض)،
                      گزارش دقیقاً با خط «تاریخ: ...» آغاز می‌شود.
    """
    lines = []
    if title:
        lines.append(title)
    lines += [
        REPORT_HEADER_TEMPLATE.format(date=report_date),
        REPORT_SEPARATOR,
    ]

    if tasks:
        for index, task in enumerate(tasks, start=1):
            lines.append(REPORT_ITEM_TEMPLATE.format(
                title=task.title,
                status=task.status_text,
                priority=task.priority,
            ))
    else:
        lines.append("(هیچ کاری برای این تاریخ ثبت نشده است.)")

    # --- بخش آمار پایانی ----------------------------------------------------
    total = len(tasks)
    done = sum(1 for t in tasks if t.is_done)
    pending = total - done
    percent = (done / total * 100) if total else 0.0

    lines += [
        REPORT_SEPARATOR,
        f"جمع کل: {total} کار | انجام‌شده: {done} | انجام‌نشده: {pending} | پیشرفت: {percent:.0f}٪",
        f"تاریخ تهیه گزارش: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
    ]
    return "\n".join(lines)


def build_range_report(tasks: list[Task], start_date: str, end_date: str) -> str:
    """گزارش متنی برای یک بازه‌ی زمانی (تسک‌ها بر اساس تاریخ سررسید گروه‌بندی می‌شوند).

    قالب هر تسک دقیقاً مطابق قالب استاندارد تک‌روزه است.
    """
    lines = [
        f"گزارش بازه‌ی زمانی {start_date} تا {end_date}",
        f"بازه: {start_date} تا {end_date}",
        REPORT_SEPARATOR,
    ]

    if not tasks:
        lines.append("(هیچ کاری در این بازه یافت نشد.)")
    else:
        # گروه‌بندی تسک‌ها بر اساس تاریخ سررسید
        grouped: dict[str, list[Task]] = {}
        for task in tasks:
            grouped.setdefault(task.due_date or "-", []).append(task)

        for due in sorted(grouped):
            lines.append(REPORT_HEADER_TEMPLATE.format(date=due))
            for task in grouped[due]:
                lines.append(REPORT_ITEM_TEMPLATE.format(
                    title=task.title,
                    status=task.status_text,
                    priority=task.priority,
                ))
            lines.append("")  # خط خالی بین روزها

    total = len(tasks)
    done = sum(1 for t in tasks if t.is_done)
    percent = (done / total * 100) if total else 0.0
    lines += [
        REPORT_SEPARATOR,
        f"جمع کل: {total} کار | انجام‌شده: {done} | انجام‌نشده: {total - done} | پیشرفت: {percent:.0f}٪",
        f"تاریخ تهیه گزارش: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
    ]
    return "\n".join(lines)


def build_full_report(todo_list: TodoList) -> str:
    """گزارش کامل همه‌ی تسک‌ها (برای فیلتر «همه» در فرم گزارش‌گیری)."""
    lines = [
        "گزارش کامل تمام کارها",
        REPORT_HEADER_TEMPLATE.format(date=today_str()),
        REPORT_SEPARATOR,
    ]
    tasks = todo_list.list_tasks()
    if tasks:
        for task in tasks:
            lines.append(REPORT_ITEM_TEMPLATE.format(
                title=task.title, status=task.status_text, priority=task.priority))
    else:
        lines.append("(هیچ کاری ثبت نشده است.)")

    stats = todo_list.statistics()
    lines += [
        REPORT_SEPARATOR,
        f"جمع کل: {stats['total']} کار | انجام‌شده: {stats['done']} | "
        f"انجام‌نشده: {stats['pending']} | عقب‌افتاده: {stats['overdue']}",
        f"تاریخ تهیه گزارش: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
    ]
    return "\n".join(lines)


def report_for_date(todo_list: TodoList, target_date: str) -> str:
    """گزارش استاندارد کارهای یک روز خاص (اتصال مستقیم به list_by_date)."""
    return build_daily_report(todo_list.list_by_date(target_date), target_date)


def default_report_filename(target_date: str) -> str:
    """نام فایل پیشنهادی برای خروجی گزارش، مثل report_2026-11-18.txt"""
    return f"report_{target_date}.txt"


def save_report(report_text: str, filename: str) -> str:
    """ذخیره‌ی متن گزارش در فایل و بازگرداندن مسیر مطلق فایل."""
    path = Path(filename)
    path.write_text(report_text, encoding="utf-8")
    return str(path.resolve())


# === ۳) گزارش‌های چندروزه (بازه) — کلیدهای تاریخ برای فرم گزارش =============
def last_7_days_range() -> tuple[str, str]:
    """بازه‌ی ۷ روز اخیر (تا امروز)."""
    end = date.today()
    start = end - timedelta(days=6)
    return start.strftime(DATE_FORMAT), end.strftime(DATE_FORMAT)


def next_7_days_range() -> tuple[str, str]:
    """بازه‌ی ۷ روز آینده (از امروز)."""
    start = date.today()
    end = start + timedelta(days=6)
    return start.strftime(DATE_FORMAT), end.strftime(DATE_FORMAT)


# === ۴) وضعیت و رنگ‌بندی اولویت‌ها ==========================================
#: رنگ پس‌زمینه/متن برای هر اولویت (استفاده در جدول و برچسب‌ها)
PRIORITY_COLORS = {
    "بالا":  {"bg": "#FDECEA", "fg": "#B71C1C"},
    "متوسط": {"bg": "#FFF8E1", "fg": "#8D6E00"},
    "پایین": {"bg": "#E8F5E9", "fg": "#1B5E20"},
}

#: رنگ تسک‌های انجام‌شده (خاکستری) و عقب‌افتاده (قرمز)
COLOR_DONE = "#9E9E9E"
COLOR_OVERDUE = "#C62828"


def priority_color(priority: str) -> dict:
    """دریافت رنگ متناظر با اولویت (با مقدار پیش‌فرض برای مقادیر ناشناخته)."""
    return PRIORITY_COLORS.get(priority, {"bg": "#F5F5F5", "fg": "#333333"})


# === ۵) اعلان / Notification ================================================
class Notifier:
    """کلاس ارسال اعلان با اولویت استفاده از plyer و جایگزین Tkinter.

    طرز کار:
        1) اگر plyer نصب باشد → اعلان دسکتاپ (System Notification)
        2) در غیر این صورت یا در صورت خطا → از tkinter.messagebox استفاده می‌شود.
    """

    APP_NAME = "To-Do List Pro"

    def __init__(self, fallback_master=None):
        # fallback_master : پنجره‌ی والد برای messagebox (در صورت نیاز)
        self.master = fallback_master
        self.using_plyer = PLYER_AVAILABLE

    def notify(self, title: str, message: str, timeout: int = 8) -> bool:
        """ارسال اعلان؛ True اگر اعلان ارسال شده باشد."""
        if self.using_plyer:
            try:
                _plyer_notification.notify(
                    title=title,
                    message=message,
                    app_name=self.APP_NAME,
                    timeout=timeout,
                )
                return True
            except Exception:
                # در بعضی سیستم‌ها (مثلاً بدون سرویس دسکتاپ) plyer خطا می‌دهد
                self.using_plyer = False
        return self._fallback_messagebox(title, message)

    def _fallback_messagebox(self, title: str, message: str) -> bool:
        """جایگزین اعلان با tkinter.messagebox."""
        try:
            from tkinter import messagebox
            messagebox.showwarning(title, message, parent=self.master)
            return True
        except Exception:
            print(f"[اعلان] {title}: {message}")
            return False

    def notify_task_alerts(self, todo_list: TodoList) -> str | None:
        """بررسی تسک‌های عقب‌افتاده و موعد امروز و ارسال یک اعلان تجمیعی.

        خروجی: متن اعلان ارسال‌شده، یا None اگر کاری نیازمند هشدار نبود.
        """
        overdue = todo_list.overdue_tasks()
        due_today = todo_list.today_tasks()

        if not overdue and not due_today:
            return None

        parts = []
        if overdue:
            parts.append(f"{len(overdue)} کار عقب‌افتاده")
        if due_today:
            parts.append(f"{len(due_today)} کار با موعد امروز")

        # نمایش دو مورد اول هر دسته در متن اعلان
        details = []
        for task in (overdue + due_today)[:3]:
            details.append(f"• {task.title}")

        message = " | ".join(parts) + "\n" + "\n".join(details)
        if len(overdue) + len(due_today) > 3:
            message += "\n…"

        self.notify("هشدار کارهای روزانه", message)
        return message


# === ۶) ابزارهای کوچک UI =====================================================
def pick_fa_font(root=None, size: int = 10) -> tuple[str, int]:
    """انتخاب هوشمند فونت فارسی موجود در سیستم.

    ترتیب اولویت: وزیرمتن → Vazirmatn → IRANSans → Tahoma → Segoe UI → DejaVu Sans
    (همیشه یک فونت موجود برمی‌گردد تا برنامه روی همه‌ی سیستم‌عامل‌ها کار کند.)
    """
    preferred = ["Vazirmatn", "Vazir", "IRANSans", "Sahel", "Shabnam",
                 "Tahoma", "Segoe UI", "Arial", "DejaVu Sans"]
    available = set()
    try:
        from tkinter import font as tkfont
        available = set(tkfont.families(root))
    except Exception:
        pass
    for name in preferred:
        if name in available:
            return name, size
    return "TkDefaultFont", size


def copy_to_clipboard(root, text: str) -> None:
    """کپی متن در کلیپ‌بورد سیستم (برای دکمه‌ی «کپی گزارش»)."""
    root.clipboard_clear()
    root.clipboard_append(text)
    root.update()  # نگه‌داشتن محتوا در کلیپ‌بورد
